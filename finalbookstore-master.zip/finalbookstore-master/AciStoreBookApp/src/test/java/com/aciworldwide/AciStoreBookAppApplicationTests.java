package com.aciworldwide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AciStoreBookAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
