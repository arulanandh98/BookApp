import { Injectable } from '@angular/core';

@Injectable()
export class Promotion{

    public pid : number;
    public code : string;
    public discount : string;
}