import { Component } from '@angular/core';

@Component({
  selector: 'approot',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'project';
}
