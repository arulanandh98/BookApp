module.exports = function() {
    return {
        books: [
            { id: 1, booktitle: "Kayak", bookauthor: "Watersports",  bookprice: 275,bookquantity:1},
            { id: 2, booktitle: "LifeJacket", bookauthor: "Watersports",  bookprice: 48.95,bookquantity:2},
            { id: 3, booktitle: "Soccer Ball ", bookauthor: "Soccer", bookprice: 19.50,bookquantity:3},
            { id: 4, booktitle: "Corner Flags", bookauthor: "Soccer", bookprice: 34.95,bookquantity:4},
            { id: 5, booktitle: "Stadium ", bookauthor: "Soccer",  bookprice: 83000,bookquantity:5}
           
        ],
        customer : []
    }
}